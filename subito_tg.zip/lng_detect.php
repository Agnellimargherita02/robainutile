<?php 
// lenguage detection
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
if(property_exists(json_decode($php_js->texts),$lang)){
  $php_js->lng=$lang;
}


 ?>