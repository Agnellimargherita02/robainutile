<?php
//new php file


$request = file_get_contents("http://ip-api.com/json"); // gets the raw data
$params = json_decode($request,true); // true for return as array
$php_js->geo=$params;

 ?>
