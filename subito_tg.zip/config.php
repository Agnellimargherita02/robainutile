<?php



// edit config.php / cfg.php / home.php 
$bot_token = "";
$chat_id = "";
