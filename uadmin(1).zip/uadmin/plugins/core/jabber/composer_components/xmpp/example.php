<?php

require 'vendor/autoload.php';
error_reporting(-1);

use Fabiang\Xmpp\Client;
use Fabiang\Xmpp\Options;
use Fabiang\Xmpp\Protocol\Message;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;

$logger = new Logger('xmpp');
$logger->pushHandler(new StreamHandler('php://stdout', Logger::DEBUG));

$hostname       = 'exploit.im';
$port           = 5222;
$connectionType = 'tcp';
$address        = "$connectionType://$hostname:$port";

$username = 'uapstoken';
$password = '1qazzaq1';

$options = new Options($address);
$options->setLogger($logger)
    ->setUsername($username)
    ->setPassword($password);

$client = new Client($options);

$client->connect();
// $client->send(new Roster);
// $client->send(new Presence);
// $client->send(new Message);

$message = new Message;
$message->setMessage("test")->setTo("-50-@exploit.im");
$client->send($message);

$client->disconnect();
