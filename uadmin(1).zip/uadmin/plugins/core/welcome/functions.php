<?php
//new php file
if (!defined('UADMIN_AB_ROOT')) {die("You not have permisions");}