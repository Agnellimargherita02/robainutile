<?php
if (!defined('UADMIN_AB_ROOT')) {die("You not have permisions");}
session_start();
