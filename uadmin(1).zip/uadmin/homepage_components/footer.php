<?php 
if (!defined('UADMIN_AB_ROOT')) {die("You not have permisions");}
 ?>


<!-- BS3-->
<script src="bower_components/bootstrap/dist/js/bootstrap.bundle.min.js" charset="utf-8"></script>
<!-- BS3-->






<!-- jQuery UI -->
<!-- <script src="bower_components/jquery-ui/jquery-ui.min.js"></script> -->
<!-- jQuery UI -->

<!-- Bootbox-->
<script src="bower_components/bootbox.js/dist/bootbox.min.js"></script>
<!-- Bootbox-->

<!-- Bootstrap notify-->
<script src="bower_components/remarkable-bootstrap-notify/dist/bootstrap-notify.min.js"></script>
<!-- Bootstrap notify-->


<!-- DataTable -->
<script type="text/javascript" src="node_modules/datatables.net/js/jquery.dataTables.min.js"></script>
<!-- <script type="text/javascript" src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script> -->

<script type="text/javascript" src="node_modules/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<!-- <script type="text/javascript" src="bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script> -->



<script type="text/javascript" src="node_modules/datatables.net-select/js/dataTables.select.min.js"></script>
<!-- <script type="text/javascript" src="bower_components/datatables.net-select/js/dataTables.select.min.js"></script> -->

<script type="text/javascript" src="node_modules/datatables.net-select-bs4/js/select.bootstrap4.min.js"></script>
<!-- <script type="text/javascript" src="bower_components/datatables.net-select-bs4/js/select.bootstrap4.min.js"></script> -->

<!-- DataTable -->



<!-- custom -->
<script type="text/javascript" src="js/main.js"></script>
<!-- custom -->


</body>
</html>
